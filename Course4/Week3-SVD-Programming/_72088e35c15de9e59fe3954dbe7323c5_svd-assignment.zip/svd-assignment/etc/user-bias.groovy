import org.lenskit.bias.BiasModel
import org.lenskit.bias.UserBiasModel

bind BiasModel to UserBiasModel