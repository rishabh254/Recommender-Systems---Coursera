import org.lenskit.bias.BiasModel
import org.lenskit.bias.UserItemBiasModel

bind BiasModel to UserItemBiasModel