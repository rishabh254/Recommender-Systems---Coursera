import org.lenskit.bias.BiasModel
import org.lenskit.bias.GlobalBiasModel

bind BiasModel to GlobalBiasModel
