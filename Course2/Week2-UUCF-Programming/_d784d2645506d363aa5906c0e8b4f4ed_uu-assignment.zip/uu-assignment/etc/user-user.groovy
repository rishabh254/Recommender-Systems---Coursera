import org.lenskit.api.ItemScorer
import org.lenskit.mooc.uu.SimpleUserUserItemScorer

// use our item scorer
bind ItemScorer to SimpleUserUserItemScorer